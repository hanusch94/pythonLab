def ketto(szam):
    return szam*2

def harom(szam):
    return szam*3

def negy(szam):
    return szam*4

def ot(szam):
    return szam*5

def hiba():
    a = 2+"s"